import 'package:flutter/material.dart';

/// A page that allows farmers to calculate the daily feed requirement for
/// their fish stock based on fish count, average weight and pond dimensions.
///
/// The UI follows the design from the provided screenshot: two form sections
/// collect fish population and pond dimensions, a button triggers the
/// calculation, and the results are displayed in styled cards.  The logic
/// uses a simple classification table (fry, fingerlings, juveniles, adults)
/// to select the appropriate feeding rate and feeding frequency.  Feed
/// density is also calculated and compared to a safe range (< 20 g/m³).
class FeedCalculatorPage extends StatefulWidget {
  const FeedCalculatorPage({super.key});

  @override
  FeedCalculatorPageState createState() => FeedCalculatorPageState();
}

class FeedCalculatorPageState extends State<FeedCalculatorPage> {
  final TextEditingController _fishCountController = TextEditingController();
  final TextEditingController _avgWeightController = TextEditingController();
  final TextEditingController _lengthController = TextEditingController();
  final TextEditingController _widthController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();

  double? _dailyFeed;      // Daily feed amount in grams
  int? _frequency;         // Feeding frequency (times/day)
  double? _feedPerSession; // Feed per feeding session in grams
  double? _feedDensity;    // Feed density (g per m³)
  String? _classification; // Fish life stage (Fry/Fingerlings/Juveniles/Adults)
  bool? _isDensitySafe;    // Whether feed density is within safe range

  /// Performs the feed calculation based on input values.
  void _calculateFeed() {
    final int? count = int.tryParse(_fishCountController.text);
    final double? weight = double.tryParse(_avgWeightController.text);
    final double? length = double.tryParse(_lengthController.text);
    final double? width = double.tryParse(_widthController.text);
    final double? height = double.tryParse(_heightController.text);

    if (count == null || weight == null || length == null || width == null || height == null) {
      // Show a simple dialog if any input is invalid.
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Invalid input'),
          content: const Text('Please enter valid numeric values for all fields.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }

    // Determine fish classification, feeding rate and frequency based on average weight (g).
    String stage;
    double rate;
    int freq;
    final double weightGrams = weight; // treat input weight as grams
    if (weightGrams <= 1.0) {
      stage = 'Fry';
      rate = 0.15; // 15% of body weight
      freq = 4;
    } else if (weightGrams <= 10.0) {
      stage = 'Fingerlings';
      rate = 0.10; // 10% of body weight
      freq = 2;
    } else if (weightGrams <= 25.0) {
      stage = 'Juveniles';
      rate = 0.05; // 5% of body weight
      freq = 2;
    } else {
      stage = 'Adults';
      rate = 0.03; // 3% of body weight
      freq = 2;
    }

    final double biomass = count * weightGrams;       // total biomass in grams
    final double daily = biomass * rate;              // daily feed amount in grams
    final double perSession = daily / freq;           // feed per session in grams
    final double volume = length * width * height;    // pond volume in cubic metres
    final double density = volume > 0 ? daily / volume : 0.0; // feed density g/m³
    final bool safe = density <= 20.0;                // safe if <= 20 g/m³

    setState(() {
      _classification = stage;
      _dailyFeed = daily;
      _frequency = freq;
      _feedPerSession = perSession;
      _feedDensity = density;
      _isDensitySafe = safe;
    });
  }

  @override
  void dispose() {
    _fishCountController.dispose();
    _avgWeightController.dispose();
    _lengthController.dispose();
    _widthController.dispose();
    _heightController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Feed Calculator'),
        backgroundColor: const Color(0xFF2563EB),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Fish Population',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _buildNumberField(
                    controller: _fishCountController,
                    label: 'Fish Count',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildNumberField(
                    controller: _avgWeightController,
                    label: 'Average Weight (g)',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text(
              'Pond Dimension',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _buildNumberField(
                    controller: _lengthController,
                    label: 'Length (m)',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildNumberField(
                    controller: _widthController,
                    label: 'Width (m)',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildNumberField(
                    controller: _heightController,
                    label: 'Height (m)',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _calculateFeed,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2563EB),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Calculate Feed Amount',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            ),
            const SizedBox(height: 20),
            if (_dailyFeed != null) ...[
              _buildResultCard(
                title: 'Daily Recommended Feeds',
                value: '${_dailyFeed!.toStringAsFixed(0)} g',
              ),
              const SizedBox(height: 12),
              _buildResultCard(
                title: 'Feeding Frequency',
                value: '$_frequency times/day',
                subtitle: 'Based on fish classification: ${_classification ?? ''}',
              ),
              const SizedBox(height: 12),
              _buildResultCard(
                title: 'Feed per Session',
                value: '${_feedPerSession!.toStringAsFixed(2)} g',
              ),
              const SizedBox(height: 12),
              _buildResultCard(
                title: 'Feed Density',
                value: '${_feedDensity!.toStringAsFixed(2)} g/m³',
                subtitle: _isDensitySafe == true ? 'Safe Range' : 'Exceeds Safe Range',
                subtitleColor: _isDensitySafe == true ? Colors.green : Colors.red,
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Builds a numeric input field with consistent styling.
  Widget _buildNumberField({
    required TextEditingController controller,
    required String label,
  }) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      ),
    );
  }

  /// Builds a result card displaying a calculated value.
  Widget _buildResultCard({
    required String title,
    required String value,
    String? subtitle,
    Color subtitleColor = Colors.grey,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 6,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.black54,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2563EB),
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 12,
                color: subtitleColor,
              ),
            ),
          ],
        ],
      ),
    );
  }
}