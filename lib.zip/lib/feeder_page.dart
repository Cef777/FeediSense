import 'package:flutter/material.dart';
import 'package:another_telephony/telephony.dart';
import 'sms_config.dart';

class FeederPage extends StatefulWidget {
  const FeederPage({super.key});

  @override
  _FeederPageState createState() => _FeederPageState();
}

class _FeederPageState extends State<FeederPage> {
  final Telephony telephony = Telephony.instance;
  final List<TimeOfDay> _times = List<TimeOfDay>.generate(4, (i) => TimeOfDay(hour: 8 + i * 2, minute: 0));
  final List<TextEditingController> _feedAmountControllers = List.generate(4, (_) => TextEditingController());
  final TextEditingController _manualFeedController = TextEditingController();

  Future<void> _sendDirectSMS(String message) async {
    // Uses the plugin's built-in permission solicitor
    bool? permissionsGranted = await telephony.requestPhonePermissions;

    if (permissionsGranted == true) {
      try {
        await telephony.sendSms(
          to: SmsConfig.phoneNumber,
          message: message,
          // CRITICAL FIX: Use 'dynamic' to avoid type mismatch and constant name errors
          statusListener: (dynamic status) {
            final String statusString = status.toString().toLowerCase();
            if (statusString.contains('sent')) {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Command Sent: $message')),
                );
              }
            }
          },
        );
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $error')),
          );
        }
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('SMS Permission Denied')),
        );
      }
    }
  }

  Future<void> _pickTime(int index) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _times[index],
    );
    if (picked != null) {
      setState(() {
        _times[index] = picked;
      });
    }
  }

  void _updateSchedules() {
    String scheduleMsg = "SCHED";
    for (int i = 0; i < 4; i++) {
      String timeStr = "${_times[i].hour.toString().padLeft(2, '0')}${_times[i].minute.toString().padLeft(2, '0')}";
      String amount = _feedAmountControllers[i].text.isEmpty ? "0" : _feedAmountControllers[i].text;
      scheduleMsg += "|$timeStr,$amount";
    }
    _sendDirectSMS(scheduleMsg);
  }

  void _triggerManualFeed() {
    final String amount = _manualFeedController.text;
    if (amount.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a feed amount.')),
      );
      return;
    }
    _sendDirectSMS("FEED,$amount");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Feeder Control'),
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Daily Feeding Schedule', 
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...List.generate(4, (index) => _buildScheduleRow(index)),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _updateSchedules,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2563EB),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Update All Schedules', 
                style: TextStyle(fontSize: 16, color: Colors.white)),
            ),
            const SizedBox(height: 32),
            const Text('Manual Trigger', 
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildManualSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildScheduleRow(int index) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12), 
        side: BorderSide(color: Colors.grey.shade200)
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Text('Session ${index + 1}', 
              style: const TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            TextButton(
              onPressed: () => _pickTime(index),
              child: Text(_times[index].format(context)),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 80,
              child: TextField(
                controller: _feedAmountControllers[index],
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: 'grams', 
                  border: OutlineInputBorder()
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildManualSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade50, 
        borderRadius: BorderRadius.circular(16)
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: TextField(
              controller: _manualFeedController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Feed (g)',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12), 
                  borderSide: BorderSide.none
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: _triggerManualFeed,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2563EB),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Trigger', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
}