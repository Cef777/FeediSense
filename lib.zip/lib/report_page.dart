import 'package:flutter/material.dart';
import 'package:another_telephony/telephony.dart';
import 'sms_config.dart';

class ReportPage extends StatefulWidget {
  const ReportPage({super.key});

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  final Telephony telephony = Telephony.instance;
  double temperature = 28.0; 
  double pH = 7.2;           
  double dissolvedOxygen = 6.5; 
  bool _isUpdating = false;

  Future<void> _requestUpdate() async {
    bool? permissionsGranted = await telephony.requestPhonePermissions;

    if (permissionsGranted != true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('SMS Permission required.')),
      );
      return;
    }

    setState(() { _isUpdating = true; });
    
    try {
      // Using a slightly different method to avoid the listener type error
      await telephony.sendSms(
        to: SmsConfig.phoneNumber,
        message: "SEND_DATA",
        // We use an anonymous function but cast the status to dynamic 
        // to stop the compiler from complaining about the enum name
        statusListener: (dynamic status) {
          if (status.toString().contains('Sent') || status.toString().contains('SENT')) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Update request sent.')),
            );
          }
        },
      );
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: $error')),
      );
    } finally {
      if (mounted) {
        setState(() { _isUpdating = false; });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Water Quality Report'),
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            _buildStatusCard(),
            const SizedBox(height: 24),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              children: [
                _buildDetailItem(Icons.thermostat, 'Temp', '$temperature°C'),
                _buildDetailItem(Icons.opacity, 'pH', '$pH'),
                _buildDetailItem(Icons.waves, 'Oxygen', '$dissolvedOxygen'),
              ],
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: _isUpdating ? null : _requestUpdate,
                icon: const Icon(Icons.refresh, color: Colors.white),
                label: Text(
                  _isUpdating ? 'Requesting...' : 'Request Latest Readings',
                  style: const TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      width: double.infinity,
      decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(20)),
      child: const Column(
        children: [
          Icon(Icons.check_circle, color: Colors.green, size: 48),
          Text('Optimal Water Quality', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
        ],
      ),
    );
  }

  Widget _buildDetailItem(IconData icon, String title, String value) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white, 
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.blue),
          Text(title, style: const TextStyle(fontSize: 12)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}