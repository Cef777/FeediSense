import 'dart:developer' as developer; // Correct: Imports stay at the top

class SensorReading {
  final double temp;
  final double ph;
  final double doLevel;
  final DateTime timestamp;

  SensorReading({
    required this.temp,
    required this.ph,
    required this.doLevel,
    required this.timestamp,
  });
}

class AppNotification {
  final String level;
  final String message;
  final DateTime timestamp;

  AppNotification({required this.level, required this.message, required this.timestamp});
}

class SmsHandler {
  // Central storage
  static List<SensorReading> history = [];
  static List<AppNotification> notifications = [];

  // Call this when an SMS arrives from the Arduino
  static void processSms(String message) {
    DateTime now = DateTime.now();

    // 1. Handle Status Alerts (Text-based)
    if (message.contains("aborted")) {
      notifications.add(AppNotification(level: 'High', message: message, timestamp: now));
    } else if (message.contains("reduced")) {
      notifications.add(AppNotification(level: 'Medium', message: message, timestamp: now));
    } else if (message.startsWith("FEED,")) {
      notifications.add(AppNotification(level: 'Low', message: "Feeder Status: ${message.split(',')[1]}", timestamp: now));
    } 
    // 2. Handle Sensor Data (e.g. "28.5,7.2,6.5")
    else {
      try {
        List<String> parts = message.split(',');
        if (parts.length >= 3) {
          double t = double.parse(parts[0]);
          double p = double.parse(parts[1]);
          double d = double.parse(parts[2]);
          
          history.add(SensorReading(temp: t, ph: p, doLevel: d, timestamp: now));
          
          // Logic: Auto-generate notification if water is bad
          if (d < 5.0) {
            notifications.add(AppNotification(
              level: 'High', 
              message: 'Low Oxygen Alert: $d mg/L detected.', 
              timestamp: now
            ));
          }
        }
      } catch (e) {
        // Removed the import from here
        developer.log("Error parsing SMS data: $e", name: 'SmsHandler');
      }
    }
  }

  static void init(void Function() callback) {
    // Initialization logic if needed
  }
}