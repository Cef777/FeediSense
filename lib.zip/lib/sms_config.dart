/// Global configuration for SMS settings.
///
/// This class stores configuration values used across the app, such as the
/// phone number of the hardware prototype that receives SMS commands.
class SmsConfig {
  /// The phone number that the app will send SMS messages to.
  ///
  /// This value can be updated by the user from the About page.  It is
  /// initialised with a default Philippine phone number.  Other parts of
  /// the application (such as the Feeder page) read from this field when
  /// sending messages via the `flutter_sms` plugin.
  static String phoneNumber = '+639087100831';
}