import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'sms_handler.dart';

class AnalyticsPage extends StatelessWidget {
  const AnalyticsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<SensorReading> data = SmsHandler.history;

    // Handle Empty State
    if (data.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Feeding Impact Analytics'), backgroundColor: const Color(0xFF2563EB), foregroundColor: Colors.white),
        body: const Center(child: Text('Waiting for SMS data from prototype...')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Feeding Impact Analytics'),
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Actionable Insights', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            
            // Insight logic based on real data
            _buildInsightCard(
              icon: data.any((r) => r.doLevel < 5.0) ? Icons.warning_amber_rounded : Icons.check_circle_outline,
              iconColor: data.any((r) => r.doLevel < 5.0) ? Colors.orange : Colors.green,
              title: data.any((r) => r.doLevel < 5.0) ? 'Oxygen Fluctuation' : 'Stable Quality',
              message: data.any((r) => r.doLevel < 5.0) 
                ? 'Recent reports show Dissolved Oxygen dropping below 5.0 mg/L.' 
                : 'All water quality parameters are currently within the safe zone.',
            ),
            
            const SizedBox(height: 24),
            const Text('Current Averages', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            
            Row(
              children: [
                Expanded(child: _buildCorrelationStat('Avg DO', _avg(data, 'do'), Colors.teal)),
                const SizedBox(width: 12),
                Expanded(child: _buildCorrelationStat('Avg pH', _avg(data, 'ph'), Colors.indigo)),
              ],
            ),
            
            const SizedBox(height: 24),
            const Text('Recent Trend: Oxygen', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _buildTrendChart(data: data, metricKey: 'do', metricName: 'DO (mg/L)', metricColor: Colors.teal, safeThreshold: 5.0),

            const SizedBox(height: 24),
            const Text('Recent Trend: pH', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _buildTrendChart(data: data, metricKey: 'ph', metricName: 'pH Level', metricColor: Colors.indigo, safeThreshold: 6.5),
          ],
        ),
      ),
    );
  }

  String _avg(List<SensorReading> data, String type) {
    double sum = 0;
    if (type == 'do') sum = data.map((e) => e.doLevel).reduce((a, b) => a + b);
    if (type == 'ph') sum = data.map((e) => e.ph).reduce((a, b) => a + b);
    return (sum / data.length).toStringAsFixed(1);
  }

  Widget _buildInsightCard({required IconData icon, required Color iconColor, required String title, required String message}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: iconColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: iconColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: iconColor, size: 28),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: iconColor)),
            Text(message, style: const TextStyle(fontSize: 13)),
          ])),
        ],
      ),
    );
  }

  Widget _buildCorrelationStat(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border(bottom: BorderSide(color: color, width: 4))),
      child: Column(children: [Text(label, style: const TextStyle(fontSize: 12)), Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color))]),
    );
  }

  Widget _buildTrendChart({required List<SensorReading> data, required String metricKey, required String metricName, required Color metricColor, required double safeThreshold}) {
    return Container(
      height: 200,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: LineChart(
        LineChartData(
          gridData: const FlGridData(show: false),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              spots: List.generate(data.length, (i) => FlSpot(i.toDouble(), metricKey == 'do' ? data[i].doLevel : data[i].ph)),
              isCurved: true,
              color: metricColor,
              dotData: const FlDotData(show: true),
            ),
          ],
        ),
      ),
    );
  }
}