import 'package:flutter/material.dart';
import 'feed_calculator_page.dart';
import 'feeder_page.dart';
import 'report_page.dart';
import 'notifications_page.dart';
import 'analytics_page.dart';
import 'about_page.dart';
import 'sms_handler.dart'; // Import our new handler

void main() {
  runApp(const FeediSenseApp());
}

class FeediSenseApp extends StatelessWidget {
  const FeediSenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FeediSense',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB),
          primary: const Color(0xFF2563EB),
          secondary: const Color(0xFF10B981),
        ),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
      ),
      home: const MainMenuPage(),
    );
  }
}

class MainMenuPage extends StatefulWidget {
  const MainMenuPage({super.key});

  @override
  State<MainMenuPage> createState() => _MainMenuPageState();
}

class _MainMenuPageState extends State<MainMenuPage> {
  
  @override
  void initState() {
    super.initState();
    // Initialize SMS listening as soon as the app opens
    SmsHandler.init(() {
      if (mounted) setState(() {}); 
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220.0,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 40),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: Image.asset(
                        'assets/4206 LOGO FEEDISENSE-modified.png',
                        height: 80,
                        errorBuilder: (context, error, stackTrace) => 
                          const Icon(Icons.water_drop, size: 60, color: Color(0xFF2563EB)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'FeediSense',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildQuickStatus(),
                  const SizedBox(height: 24),
                  const Text(
                    'Management Menu',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
                  ),
                  const SizedBox(height: 16),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 1.1,
                    children: [
                      _MenuCard(
                        icon: Icons.calculate_outlined,
                        label: 'Feed Calculator',
                        color: Colors.blue,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => const FeedCalculatorPage())),
                      ),
                      _MenuCard(
                        icon: Icons.settings_input_component,
                        label: 'Feeder Control',
                        color: Colors.orange,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => const FeederPage())),
                      ),
                      _MenuCard(
                        icon: Icons.assignment_outlined,
                        label: 'Water Report',
                        color: Colors.teal,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => const ReportPage())),
                      ),
                      _MenuCard(
                        icon: Icons.insights_outlined,
                        label: 'Analytics',
                        color: Colors.purple,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => const AnalyticsPage())),
                      ),
                      _MenuCard(
                        icon: Icons.notifications_active_outlined,
                        label: 'Notifications',
                        color: Colors.redAccent,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => const NotificationsPage())),
                      ),
                      _MenuCard(
                        icon: Icons.info_outline,
                        label: 'About System',
                        color: Colors.grey,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (c) => const AboutPage())),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStatus() {
    bool hasData = SmsHandler.history.isNotEmpty;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: hasData ? Colors.green.withOpacity(0.3) : Colors.orange.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Row(
        children: [
          Icon(hasData ? Icons.check_circle : Icons.sync, color: hasData ? Colors.green : Colors.orange, size: 30),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Prototype Connection', style: TextStyle(color: Colors.black54, fontSize: 12)),
                Text(hasData ? 'Optimal Conditions' : 'Waiting for Data...', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ],
            ),
          ),
          Text(hasData ? 'ACTIVE' : 'PENDING', style: TextStyle(color: hasData ? Colors.green : Colors.orange, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _MenuCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _MenuCard({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 32),
              ),
              const SizedBox(height: 12),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            ],
          ),
        ),
      ),
    );
  }
}