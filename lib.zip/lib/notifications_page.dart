import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'sms_handler.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  
  void _clearNotifications() {
    setState(() {
      SmsHandler.notifications.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Notifications cleared.')),
    );
  }

  /// Implementation of the CSV Export and Share
  Future<void> _exportData() async {
    final List<SensorReading> data = SmsHandler.history;
    
    if (data.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No sensor data to export.')),
      );
      return;
    }

    // 1. Generate CSV String
    StringBuffer csv = StringBuffer();
    csv.writeln('Timestamp,Temperature(C),pH,DO(mg/L)');
    for (var reading in data) {
      csv.writeln('${reading.timestamp.toIso8601String()},${reading.temp},${reading.ph},${reading.doLevel}');
    }

    try {
      // 2. Save to a temporary file
      final directory = await getTemporaryDirectory();
      final String path = '${directory.path}/pond_data_export.csv';
      final File file = File(path);
      await file.writeAsString(csv.toString());

      // 3. Share the file via the OS share sheet
      await Share.shareXFiles(
        [XFile(path)],
        subject: 'FeediSense Water Quality Data',
        text: 'Sharing historical sensor data from my pond.',
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Export failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('History & Data'),
          backgroundColor: const Color(0xFF2563EB),
          foregroundColor: Colors.white,
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(text: 'Notifications', icon: Icon(Icons.notifications)),
              Tab(text: 'Sensor Data', icon: Icon(Icons.analytics)),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // TAB 1: NOTIFICATIONS
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: SmsHandler.notifications.isEmpty ? null : _clearNotifications,
                      icon: const Icon(Icons.clear_all),
                      label: const Text('Clear All'),
                      style: TextButton.styleFrom(foregroundColor: Colors.red),
                    ),
                  ),
                ),
                Expanded(
                  child: SmsHandler.notifications.isEmpty
                      ? const Center(child: Text('No notifications history.'))
                      : ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: SmsHandler.notifications.length,
                          separatorBuilder: (_, __) => const Divider(),
                          itemBuilder: (context, index) {
                            final item = SmsHandler.notifications[index];
                            return ListTile(
                              leading: Icon(
                                Icons.circle,
                                color: item.level == 'High' ? Colors.red : item.level == 'Medium' ? Colors.orange : Colors.blue,
                                size: 16,
                              ),
                              title: Text(item.message, style: const TextStyle(fontSize: 14)),
                              subtitle: Text(_formatTimestamp(item.timestamp)),
                            );
                          },
                        ),
                ),
              ],
            ),

            // TAB 2: SENSOR DATA
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      onPressed: SmsHandler.history.isEmpty ? null : _exportData,
                      icon: const Icon(Icons.download),
                      label: const Text('Export CSV'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2563EB),
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: SmsHandler.history.isEmpty
                      ? const Center(child: Text('No sensor data available.'))
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: SmsHandler.history.length,
                          itemBuilder: (context, index) {
                            final data = SmsHandler.history[index];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 12),
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Time: ${_formatTimestamp(data.timestamp)}', 
                                         style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
                                    const SizedBox(height: 8),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text('Temp: ${data.temp}°C'),
                                        Text('pH: ${data.ph}'),
                                        Text('DO: ${data.doLevel} mg/L'),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  static String _formatTimestamp(DateTime time) {
    final String month = time.month.toString().padLeft(2, '0');
    final String day = time.day.toString().padLeft(2, '0');
    final int hourInt = time.hour % 12 == 0 ? 12 : time.hour % 12;
    final String hour = hourInt.toString();
    final String minute = time.minute.toString().padLeft(2, '0');
    final String period = time.hour < 12 ? 'AM' : 'PM';
    return '$month/$day/${time.year} $hour:$minute $period';
  }
}